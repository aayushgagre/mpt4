package userInformation;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import PageBean.UserInformation;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class UserInformationStepDefinition {

	private WebDriver driver;
	private UserInformation bean;
	
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver",
				"D:\\bdd\\chromedriver_win32\\chromedriver.exe" );
		driver= new ChromeDriver();
	}
	
	@Given("^user is on 'UserInformation' page$")
	public void user_is_on_UserInformation_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    driver.get("D:\\New folder\\TestProject\\UserInformation.html");
	    bean=new UserInformation(driver);
	}

	@When("^user enters Applicant Name$")
	public void user_enters_Applicant_Name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		bean.setApplicantName("");
		bean.setButton();
	   
	}

	@Then("^displays 'Please fill the Applicant Name'$")
	public void displays_Please_fill_the_Applicant_Name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String expectedMessage="Please fill the Applicant Name ";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enters invalid fisrt name$")
	public void user_enters_invalid_fisrt_name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		bean.setApplicantName("Aayush Gagrai");
		bean.setFirstName("");
		bean.setButton();
	}

	@Then("^displays 'Please fill the First Name'$")
	public void displays_Please_fill_the_First_Name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String expectedMessage="Please fill the First Name ";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enters invalid last name$")
	public void user_enters_invalid_last_name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		bean.setApplicantName("Aayush Gagrai");
		bean.setFirstName("Aayush");
		bean.setLastName("");
		bean.setButton();
	}

	@Then("^displays 'Please fill the Last Name'$")
	public void displays_Please_fill_the_Last_Name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String expectedMessage="Please fill the Last Name ";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}
	@When("^user enters invalid Father Name$")
	public void user_enters_invalid_Father_Name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		bean.setApplicantName("Aayush Gagrai");
		bean.setFirstName("Aayush");
		bean.setLastName("Gagrai");
		bean.setFatherName("");
		bean.setButton();
	}

	@Then("^displays 'Please fill the Father Name'$")
	public void displays_Please_fill_the_Father_Name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String expectedMessage="Please fill the Father Name ";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enters invalid Date Of Birth$")
	public void user_enters_invalid_Date_Of_Birth() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		bean.setApplicantName("Aayush Gagrai");
		bean.setFirstName("Aayush");
		bean.setLastName("Gagrai");
		bean.setFatherName("Netrapal");
		bean.setDob("");
		bean.setButton();
	}

	@Then("^display 'Please fill Date Of Birth'$")
	public void display_Please_fill_Date_Of_Birth() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String expectedMessage="Please fill the DOB";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enters wrong Date Of Birth$")
	public void user_enters_wrong_Date_Of_Birth() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		bean.setApplicantName("Aayush Gagrai");
		bean.setFirstName("Aayush");
		bean.setLastName("Gagrai");
		bean.setFatherName("Netrapal");
		bean.setDob("12-4546-545");
		bean.setButton();
	}

	@Then("^display 'Please enter valid Date Of Birth'$")
	public void display_Please_enter_valid_Date_Of_Birth() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String expectedMessage="Please Enter valid date(dd-MM-yyyy)";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user does not select radio button field gender$")
	public void user_does_not_select_radio_button_field_gender() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		bean.setApplicantName("Aayush Gagrai");
		bean.setFirstName("Aayush");
		bean.setLastName("Gagrai");
		bean.setFatherName("Netrapal");
		bean.setDob("25-01-1998");
		bean.setGender("");
		bean.setButton();
	}

	@Then("^display 'Please select gender'$")
	public void display_Please_select_gender() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String expectedMessage="Please select the Gender";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enters invalid mobile number$")
	public void user_enters_invalid_mobile_number() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		bean.setApplicantName("Aayush Gagrai");
		bean.setFirstName("Aayush");
		bean.setLastName("Gagrai");
		bean.setFatherName("Netrapal");
		bean.setDob("25-01-1998");
		bean.setGender("Male");
		bean.setMobile("");
		bean.setButton();
	}

	@Then("^display 'Please fill the Mobile No\\.'$")
	public void display_Please_fill_the_Mobile_No() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String expectedMessage="Please fill Mobile no";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enters wrong mobile number$")
	public void user_enters_wrong_mobile_number() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		bean.setApplicantName("Aayush Gagrai");
		bean.setFirstName("Aayush");
		bean.setLastName("Gagrai");
		bean.setFatherName("Netrapal");
		bean.setDob("25-01-1998");
		bean.setGender("Male");
		bean.setMobile("256484");
		bean.setButton();
	}

	@Then("^display 'Please enter (\\d+) digit Mobile No\\.'$")
	public void display_Please_enter_digit_Mobile_No(int arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String expectedMessage="Please enter valid mobile no";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enters invalid email$")
	public void user_enters_invalid_email() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		bean.setApplicantName("Aayush Gagrai");
		bean.setFirstName("Aayush");
		bean.setLastName("Gagrai");
		bean.setFatherName("Netrapal");
		bean.setDob("25-01-1998");
		bean.setGender("Male");
		bean.setMobile("9719832969");
		bean.setMailid("");
		bean.setButton();
	}

	@Then("^display 'Please fill the Mail Id'$")
	public void display_Please_fill_the_Mail_Id() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String expectedMessage="Please fill the Email id ";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enters invalid Landline$")
	public void user_enters_invalid_Landline() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		bean.setApplicantName("Aayush Gagrai");
		bean.setFirstName("Aayush");
		bean.setLastName("Gagrai");
		bean.setFatherName("Netrapal");
		bean.setDob("25-01-1998");
		bean.setGender("Male");
		bean.setMobile("9719832969");
		bean.setMailid("aayushgagrai@gmail.com");
		bean.setLandline("");
		bean.setButton();
	}

	@Then("^display 'Please fill the Landline no\\.'$")
	public void display_Please_fill_the_Landline_no() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String expectedMessage="please fill the landline no";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}
	
	@When("^user does not select radio button field Communication$")
	public void user_does_not_select_radio_button_field_Communication() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		// Write code here that turns the phrase above into concrete actions
				bean.setApplicantName("Aayush Gagrai");
				bean.setFirstName("Aayush");
				bean.setLastName("Gagrai");
				bean.setFatherName("Netrapal");
				bean.setDob("25-01-1998");
				bean.setGender("Male");
				bean.setMobile("9719832969");
				bean.setMailid("aayushgagrai@gmail.com");
				bean.setLandline("0133124564");
				bean.setCommunication("");
				bean.setButton();
	}


	@Then("^display 'Please select Communnication'$")
	public void display_Please_select_Communnication() throws Throwable {
		String expectedMessage="Please select the Type of Communication ";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enters wrong Residence Address$")
	public void user_enters_wrong_Residence_Address() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		bean.setApplicantName("Aayush Gagrai");
		bean.setFirstName("Aayush");
		bean.setLastName("Gagrai");
		bean.setFatherName("Netrapal");
		bean.setDob("25-01-1998");
		bean.setGender("Male");
		bean.setMobile("9719832969");
		bean.setMailid("aayushgagrai@gmail.com");
		bean.setLandline("0133124564");
		bean.setCommunication("Office");
		bean.setResiAddress("");
		bean.setButton();
	    
	}

	@Then("^display 'Please enter Residence Address'$")
	public void display_Please_enter_Residence_Address() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String expectedMessage="please enter the Addresss";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	   
	}


	@When("^user enters valid  payment details$")
	public void user_enters_valid_payment_details() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		bean.setApplicantName("Aayush Gagrai");
		bean.setFirstName("Aayush");
		bean.setLastName("Gagrai");
		bean.setFatherName("Netrapal");
		bean.setDob("25-01-1998");
		bean.setGender("Male");
		bean.setMobile("9719832969");
		bean.setMailid("aayushgagrai@gmail.com");
		bean.setLandline("0133124564");
		bean.setCommunication("Office");
		bean.setResiAddress("Gangoh, Saharanpur");
		bean.setButton();
	}
	

	@Then("^displays 'Personal Details Validated!!!'$")
	public void displays_Personal_Details_Validated() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		driver.get("D:\\New folder\\TestProject\\PaymentDetails.html");
		driver.close();
	}

}
