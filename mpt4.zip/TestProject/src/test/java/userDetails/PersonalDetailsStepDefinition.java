package userDetails;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import PageBean.PersonalDetails;
import PageBean.UserInformation;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class PersonalDetailsStepDefinition {

	private WebDriver driver;
	private PersonalDetails bean;
	
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver",
				"D:\\bdd\\chromedriver_win32\\chromedriver.exe" );
		driver= new ChromeDriver();
	}
	
	@Given("^user is on 'PersonalDetails' page$")
	public void user_is_on_PersonalDetails_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		driver.get("D:\\New folder\\TestProject\\PaymentDetails.html");
	    bean=new PersonalDetails(driver);
	}

	@When("^user enters Card Holder Name$")
	public void user_enters_Card_Holder_Name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		bean.setCardHolderName("");
		bean.setMakePayment();
	}

	@Then("^displays 'Please fill the Card holder Name'$")
	public void displays_Please_fill_the_Card_holder_Name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String expectedMessage="Please fill the Card holder name";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enters invalid Debit Card Name$")
	public void user_enters_invalid_Debit_Card_Name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		bean.setCardHolderName("Aayus Gagrai");
		bean.setDebitCardNumber("");
		bean.setMakePayment();
	}

	@Then("^displays 'Please fill the Debit Card Name'$")
	public void displays_Please_fill_the_Debit_Card_Name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String expectedMessage="Please fill the Debit card Number";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enters invalid CVV$")
	public void user_enters_invalid_CVV() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		bean.setCardHolderName("Aayus Gagrai");
		bean.setDebitCardNumber("123456899");
		bean.setCvv("");
		bean.setMakePayment();
	}

	@Then("^displays 'Please fill CVV'$")
	public void displays_Please_fill_CVV() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String expectedMessage="Please fill the CVV";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enters invalid Card Expiration Month$")
	public void user_enters_invalid_Card_Expiration_Month() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		bean.setCardHolderName("Aayus Gagrai");
		bean.setDebitCardNumber("123456899");
		bean.setCvv("032");
		bean.setCardExpMonth("");
		bean.setMakePayment();
	}

	@Then("^displays 'Please fill Card Expiration Month'$")
	public void displays_Please_fill_Card_Expiration_Month() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String expectedMessage="Please fill expiration month";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enters invalid Card Expiration Year$")
	public void user_enters_invalid_Card_Expiration_Year() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		bean.setCardHolderName("Aayus Gagrai");
		bean.setDebitCardNumber("123456899");
		bean.setCvv("032");
		bean.setCardExpMonth("12");
		bean.setCardExpYear("");
		bean.setMakePayment();
	}

	@Then("^display 'Please fill Card Expiration Year'$")
	public void display_Please_fill_Card_Expiration_Year() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String expectedMessage="Please fill expiration year";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}
	
	@When("^user enters valid  payment details$")
	public void user_enters_valid_payment_details() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		bean.setCardHolderName("Aayus Gagrai");
		bean.setDebitCardNumber("123456899");
		bean.setCvv("032");
		bean.setCardExpMonth("12");
		bean.setCardExpYear("2021");
		bean.setMakePayment();
	}

	@Then("^displays 'Pan Card Registration Done Successfully!!!'$")
	public void displays_Pan_Card_Registration_Done_Successfully() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   driver.close();
	}
}
