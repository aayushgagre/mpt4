package PageBean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class UserInformation {
	
	WebDriver driver;
	
	//step 1 : identify elements
	@FindBy(name="txtNM")
	@CacheLookup
	WebElement applicantName;
	
	@FindBy(xpath="//*[@id='txtFirstName']")
	@CacheLookup
	WebElement firstName;
	
	@FindBy(xpath="//*[@id='txtLastName']")
	@CacheLookup
	WebElement lastName;
	
	@FindBy(name="txtFtName")
	@CacheLookup
	WebElement fatherName;
	
	@FindBy(how=How.NAME, using="txtDOB")
	@CacheLookup
	WebElement dob;
	
	@FindBy(name="gender")
	@CacheLookup
	WebElement gender;
	
	@FindBy(id="rdbMale")
	@CacheLookup
	WebElement rbMale;
	
	@FindBy(id="rdbFemale")
	@CacheLookup
	WebElement rbFemale;
	
	@FindBy(name="txtMNo")
	@CacheLookup
	WebElement mobile;
	
	@FindBy(how=How.NAME, using="txtEmailID")
	@CacheLookup
	WebElement mailid;
	
	@FindBy(how=How.NAME, using="txtLLine")
	@CacheLookup
	WebElement landline;
	
	@FindBy(how=How.NAME, using="communication")
	@CacheLookup
	WebElement communication;
	
	@FindBy(id="rdbResAddress")
	@CacheLookup
	WebElement rdbResAddress;
	
	@FindBy(id="rdbOfficeAdd")
	@CacheLookup
	WebElement rdbOfficeAdd;
	
	@FindBy(id="txtAResidenceAdd")
	@CacheLookup
	WebElement resiAddress;
	

	@FindBy(how=How.ID, using="btnSubmit")
	@CacheLookup
	WebElement button;

	public WebDriver getDriver() {
		return driver;
	}

	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}

	public WebElement getApplicantName() {
		return applicantName;
	}

	public void setApplicantName(String applicantName) {
		this.applicantName.sendKeys(applicantName);
	}

	public WebElement getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName.sendKeys(firstName);
	}

	public WebElement getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName.sendKeys(lastName);
	}

	public WebElement getFatherName() {
		return fatherName;
	}

	public void setFatherName(String fatherName) {
		this.fatherName.sendKeys(fatherName);
	}

	public WebElement getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob.sendKeys(dob);
	}

	public WebElement getGender() {
		return gender;
	}


	public WebElement getRbMale() {
		return rbMale;
	}

	public void setRbMale() {
		this.rbFemale.click();
	}

	public WebElement getRbFemale() {
		return rbFemale;
	}

	public void setRbFemale() {
		this.rbFemale.click();
	}
	
	
	public void setGender(String gender) {
		if(gender.equals("Male"))
		{//this.rbMale.click();
			System.out.println("Gender Male selected");
			setRbMale();
		}	
		else if(gender.equalsIgnoreCase("Female"))
			//this.rbFemale.click();
			setRbFemale();
	}
	
	public WebElement getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile.sendKeys(mobile);
	}

	public WebElement getMailid() {
		return mailid;
	}

	public void setMailid(String mailid) {
		this.mailid.sendKeys(mailid);
	}

	public WebElement getLandline() {
		return landline;
	}

	public void setLandline(String landline) {
		this.landline.sendKeys(landline);
	}

	public WebElement getCommunication() {
		return communication;
	}


	public WebElement getRdbResAddress() {
		return rdbResAddress;
	}

	public void setRdbResAddress() {
		this.rdbResAddress.click();
	}

	public WebElement getRdbOfficeAdd() {
		return rdbOfficeAdd;
	}

	public void setRdbOfficeAdd() {
		this.rdbOfficeAdd.click();
	}
	
	public void setCommunication(String communication) {
		if(communication.equals("Residence"))
		{//this.rbMale.click();
			System.out.println("Residence selected");
			setRdbResAddress();
		}	
		else if(communication.equalsIgnoreCase("Office"))
			//this.rbFemale.click();
			setRdbOfficeAdd();
	}
	
	public WebElement getResiAddress() {
		return resiAddress;
	}

	public void setResiAddress(String resiAddress) {
		this.resiAddress.sendKeys(resiAddress);
	}

	public WebElement getButton() {
		return button;
	}

	public void setButton() {
		this.button.click();
	}

	public UserInformation(WebDriver driver) {
		super();
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	

}
